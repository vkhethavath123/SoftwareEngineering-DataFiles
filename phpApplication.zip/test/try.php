<!DOCTYPE html>
<html>
<body>

<h1>Search Form</h1>

<p>Choose search criteria for Information about Terror Attacks<p>

 <form action="check.php" method="post">
  <label for="countries">Type the Year:</label>
  <input type="number" value="Enter year" name="year" id="year">
   <br><br>
   <input type="submit" value="Search">
   
  </form>
</body>
</html>
