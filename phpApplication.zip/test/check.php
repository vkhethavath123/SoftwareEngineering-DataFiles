<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "global_terrorism";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$year=trim($_POST['year']);

$sql = "SELECT Motive, number_of_victims, number_of_terrorists, Year, Month, Day, Longitude, Latitude FROM event_detail WHERE year=$year  ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  echo "<Table>
            <tr align='center'>
              <th>Motive</th>
              <th colspan='2' align='center'>Number of Victims</th>
              <th colspan='2' align='center'>Number of Terrorists</th>
              <th colspan='2' align='center'>Year</th>
              <th colspan='2' align='center'>Month</th>
              <th colspan='2' align='center'>Day</th>
              <th colspan='2' align='center'>Longitude</th>
              <th colspan='2' align='center'>Latitude</th>
            </tr>";
  while($row = $result->fetch_assoc()) {
      echo "<tr>
              <td >".$row['Motive']."<td>
              <td>".$row['number_of_victims']."<td>
              <td>".$row['number_of_terrorists']."<td>
              <td>".$row['Year']."<td>
              <td>".$row['Month']."<td>
              <td>".$row['Day']."<td>
              <td>".$row['Longitude']."<td>
              <td>".$row['Latitude']."<td>
              </tr>";
    //echo "motive: " . $row["Motive"]. " - number_of_victims: " . $row["number_of_victims"]. " - number_of_terrorists: " . $row["number_of_terrorists"]." - year: " . $row["Year"]. " - month " . $row["Month"]. " - day: " . $row["Day"]. " - longitude: " . $row["Longitude"]. " - latitude: " . $row["Latitude"].  "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>