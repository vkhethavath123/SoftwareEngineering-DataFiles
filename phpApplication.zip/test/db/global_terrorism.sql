-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov29, 2021 at 06:26 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `global_terrorism`
--

-- --------------------------------------------------------

--
-- Table structure for table `attack_type`
--

CREATE TABLE IF NOT EXISTS `attack_type` (
  `Attack_tyepeid` int(11) NOT NULL,
  `Attack_type` varchar(100) NOT NULL,
  PRIMARY KEY (`Attack_tyepeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attack_type`
--

INSERT INTO `attack_type` (`Attack_tyepeid`, `Attack_type`) VALUES
(1, 'Assassination'),
(2, 'Armed Assault'),
(3, 'Bombing/Explosion'),
(4, 'Hijacking'),
(5, 'Hostage Taking (Barricade Incident)'),
(6, 'Hostage Taking (Kidnapping)'),
(7, 'Facility/Infrastructure Attack'),
(8, 'Unarmed Assault'),
(9, 'Unknown');

-- --------------------------------------------------------

--
-- Table structure for table `before_weapon_update`
--

CREATE TABLE IF NOT EXISTS `before_weapon_update` (
  `Weapon_type_ID` int(11) NOT NULL,
  `Weapontype` varchar(100) NOT NULL,
  `Weapon_detail` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `before_weapon_update`
--

INSERT INTO `before_weapon_update` (`Weapon_type_ID`, `Weapontype`, `Weapon_detail`) VALUES
(2, 'Chemical', 'Cyanide in water supply');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `Country_ID` int(11) NOT NULL,
  `Country_Name` varchar(100) NOT NULL,
  PRIMARY KEY (`Country_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`Country_ID`, `Country_Name`) VALUES
(4, 'Afghanistan'),
(5, 'Albania'),
(6, 'Algeria'),
(7, 'Andorra'),
(8, 'Angola'),
(10, 'Antigua and Barbuda'),
(11, 'Argentina'),
(12, 'Armenia'),
(14, 'Australia'),
(15, 'Austria'),
(16, 'Azerbaijan'),
(17, 'Bahamas'),
(18, 'Bahrain'),
(19, 'Bangladesh'),
(20, 'Barbados'),
(21, 'Belgium'),
(22, 'Belize'),
(23, 'Benin'),
(25, 'Bhutan'),
(26, 'Bolivia'),
(28, 'Bosnia-Herzegovina'),
(29, 'Botswana'),
(30, 'Brazil'),
(31, 'Brunei'),
(32, 'Bulgaria'),
(33, 'Burkina Faso'),
(34, 'Burundi'),
(35, 'Belarus'),
(36, 'Cambodia'),
(37, 'Cameroon'),
(38, 'Canada'),
(41, 'Central African Republic'),
(42, 'Chad'),
(43, 'Chile'),
(44, 'China'),
(45, 'Colombia'),
(46, 'Comoros'),
(47, 'Republic of the Congo'),
(49, 'Costa Rica'),
(50, 'Croatia'),
(51, 'Cuba'),
(53, 'Cyprus'),
(54, 'Czech Republic'),
(55, 'Denmark'),
(56, 'Djibouti'),
(57, 'Dominica'),
(58, 'Dominican Republic'),
(59, 'Ecuador'),
(60, 'Egypt'),
(61, 'El Salvador'),
(62, 'Equatorial Guinea'),
(63, 'Eritrea'),
(64, 'Estonia'),
(65, 'Ethiopia'),
(66, 'Falkland Islands'),
(67, 'Fiji'),
(68, 'Finland'),
(69, 'France'),
(70, 'French Guiana'),
(71, 'French Polynesia'),
(72, 'Gabon'),
(73, 'Gambia'),
(74, 'Georgia'),
(75, 'Germany'),
(76, 'Ghana'),
(78, 'Greece'),
(80, 'Grenada'),
(81, 'Guadeloupe'),
(83, 'Guatemala'),
(84, 'Guinea'),
(85, 'Guinea-Bissau'),
(86, 'Guyana'),
(87, 'Haiti'),
(88, 'Honduras'),
(89, 'Hong Kong'),
(90, 'Hungary'),
(91, 'Iceland'),
(92, 'India'),
(93, 'Indonesia'),
(94, 'Iran'),
(95, 'Iraq'),
(96, 'Ireland'),
(97, 'Israel'),
(98, 'Italy'),
(99, 'Ivory Coast'),
(100, 'Jamaica'),
(101, 'Japan'),
(102, 'Jordan'),
(103, 'Kazakhstan'),
(104, 'Kenya'),
(106, 'Kuwait'),
(107, 'Kyrgyzstan'),
(108, 'Laos'),
(109, 'Latvia'),
(110, 'Lebanon'),
(111, 'Lesotho'),
(112, 'Liberia'),
(113, 'Libya'),
(115, 'Lithuania'),
(116, 'Luxembourg'),
(117, 'Macau'),
(118, 'Macedonia'),
(119, 'Madagascar'),
(120, 'Malawi'),
(121, 'Malaysia'),
(122, 'Maldives'),
(123, 'Mali'),
(124, 'Malta'),
(127, 'Martinique'),
(128, 'Mauritania'),
(129, 'Mauritius'),
(130, 'Mexico'),
(132, 'Moldova'),
(136, 'Morocco'),
(137, 'Mozambique'),
(138, 'Myanmar'),
(139, 'Namibia'),
(141, 'Nepal'),
(142, 'Netherlands'),
(143, 'New Caledonia'),
(144, 'New Zealand'),
(145, 'Nicaragua'),
(146, 'Niger'),
(147, 'Nigeria'),
(149, 'North Korea'),
(151, 'Norway'),
(153, 'Pakistan'),
(155, 'West Bank and Gaza Strip'),
(156, 'Panama'),
(157, 'Papua New Guinea'),
(158, 'Paraguay'),
(159, 'Peru'),
(160, 'Philippines'),
(161, 'Poland'),
(162, 'Portugal'),
(164, 'Qatar'),
(166, 'Romania'),
(167, 'Russia'),
(168, 'Rwanda'),
(173, 'Saudi Arabia'),
(174, 'Senegal'),
(175, 'Serbia-Montenegro'),
(176, 'Seychelles'),
(177, 'Sierra Leone'),
(178, 'Singapore'),
(179, 'Slovak Republic'),
(180, 'Slovenia'),
(181, 'Solomon Islands'),
(182, 'Somalia'),
(183, 'South Africa'),
(184, 'South Korea'),
(185, 'Spain'),
(186, 'Sri Lanka'),
(189, 'St. Kitts and Nevis'),
(190, 'St. Lucia'),
(195, 'Sudan'),
(196, 'Suriname'),
(197, 'Swaziland'),
(198, 'Sweden'),
(199, 'Switzerland'),
(200, 'Syria'),
(201, 'Taiwan'),
(202, 'Tajikistan'),
(203, 'Tanzania'),
(204, 'Togo'),
(205, 'Thailand'),
(207, 'Trinidad and Tobago'),
(208, 'Tunisia'),
(209, 'Turkey'),
(210, 'Turkmenistan'),
(213, 'Uganda'),
(214, 'Ukraine'),
(215, 'United Arab Emirates'),
(217, 'United States'),
(218, 'Uruguay'),
(219, 'Uzbekistan'),
(220, 'Vanuatu'),
(221, 'Vatican City'),
(222, 'Venezuela'),
(223, 'Vietnam'),
(226, 'Wallis and Futuna'),
(228, 'Yemen'),
(229, 'Democratic Republic of the Congo'),
(230, 'Zambia'),
(231, 'Zimbabwe'),
(235, 'Yugoslavia'),
(236, 'Czechoslovakia'),
(347, 'East Timor'),
(349, 'Western Sahara'),
(359, 'Soviet Union'),
(362, 'West Germany (FRG)'),
(377, 'North Yemen'),
(403, 'Rhodesia'),
(406, 'South Yemen'),
(422, 'International'),
(428, 'South Vietnam'),
(499, 'East Germany (GDR)'),
(525, 'temp'),
(532, 'New Hebrides'),
(603, 'United Kingdom'),
(604, 'Zaire'),
(605, 'Peoples Republic of the Congo'),
(1001, 'Serbia'),
(1002, 'Montenegro'),
(1003, 'Kosovo'),
(1004, 'South Sudan');

-- --------------------------------------------------------

--
-- Table structure for table `event_detail`
--

CREATE TABLE IF NOT EXISTS `event_detail` (
  `Event_ID` int(11) NOT NULL,
  `Year` int(11) NOT NULL,
  `Month` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Longitude` decimal(5,2) NOT NULL,
  `Latitude` decimal(5,2) NOT NULL,
  `Motive` varchar(100) NOT NULL,
  `number_of_victims` int(11) NOT NULL,
  `number_of_terrorists` int(11) NOT NULL,
  `Attack_tyepeid` int(11) NOT NULL,
  PRIMARY KEY (`Event_ID`),
  KEY `Event_detail_Attack_type` (`Attack_tyepeid`),
  KEY `idx_date` (`Year`,`Month`,`Day`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_detail`
--

INSERT INTO `event_detail` (`Event_ID`, `Year`, `Month`, `Day`, `Longitude`, `Latitude`, `Motive`, `number_of_victims`, `number_of_terrorists`, `Attack_tyepeid`) VALUES
(1090002, 1970, 1, 9, '18.39', '-66.06', 'To protest United States owned businesses in Puerto Rico', 999, 99, 1),
(1190002, 1970, 1, 19, '47.61', '-122.33', 'The incident took place during disturbances between the Black Student Union and the university.', 999, 24, 6),
(1190003, 1970, 1, 19, '47.61', '-122.33', 'The incident took place during heightened antiwar sentiments in Seattle Washington.', 1, 99, 1),
(1220002, 1970, 1, 22, '42.47', '-96.41', 'The attack occurred during the violent Iowa Beef Packers strike in South Sioux City.', 1, 2, 3),
(1260001, 1970, 1, 26, '33.61', '-88.65', 'African American opposition to the school integration plan instituted by the federal government.  Th', 1, 99, 7),
(1300003, 1970, 1, 30, '25.72', '-80.28', 'To protest the R.O.T.C. program and the War in Vietnam', 6, 12, 1),
(2040001, 1970, 2, 4, '41.08', '-81.51', 'The attack occurred during the violent Iowa Beef Packers strike.', 1, 99, 3),
(2060001, 1970, 2, 6, '39.76', '-104.88', 'Sabotage/protest the integration of Denver City Schools.', 1, 6, 7),
(2060002, 1970, 2, 6, '47.61', '-122.33', 'To intimidate/show dissatisfaction with White sympathizers of the African American cause.', 2, 7, 7),
(2060007, 1970, 2, 6, '42.35', '-71.11', 'To protest the R.O.T.C. program', 2, 1, 3),
(2080001, 1970, 2, 8, '40.70', '-73.93', 'To fight imperialism and exploitation.', 2, 6, 7),
(2090004, 1970, 2, 9, '39.08', '-84.18', 'Protest employees of General Electric who were not union members', 999, 99, 7),
(2130003, 1970, 2, 13, '37.87', '-122.28', 'To intimidate the police.', 8, 2, 3),
(2170003, 1970, 2, 17, '30.49', '-90.13', 'Suspected motive was to protest school integration.', 1, 99, 9),
(2170004, 1970, 2, 17, '47.61', '-122.33', 'Protest the War in Vietnam', 1, 99, 3),
(2210005, 1970, 2, 21, '40.70', '-73.93', 'Protest Vietnam War and show support for Black Panthers.', 1, 6, 3),
(2220002, 1970, 2, 22, '43.29', '-89.72', 'To sabotage the Badger Ammunition Plant', 8, 2, 7),
(2230005, 1970, 2, 23, '32.22', '-110.93', 'Protest the draft.', 999, 5, 2),
(2240002, 1970, 2, 24, '39.76', '-104.88', 'Protest the desegregation of Denver City Schools.', 1, 99, 3),
(2240003, 1970, 2, 24, '40.10', '-88.23', 'Protest secret government research at the University of Illinois and the R.O.T.C. program.', 1, 75, 3),
(3010005, 1970, 3, 1, '40.01', '-105.27', 'Protest the Vietnam War and the R.O.T.C.', 1, 99, 7),
(3010006, 1970, 3, 1, '38.86', '-104.78', 'Protest the War in Vietnam and sabotage the draft', 1, 99, 1),
(3140004, 1970, 3, 14, '33.77', '-118.19', 'To impede the US war effort and protest the Vietnam War', 130, 2, 7),
(3200002, 1970, 3, 20, '42.33', '-83.05', 'To protest the civil rights movement', 4, 99, 7),
(3210003, 1970, 3, 21, '40.70', '-73.93', 'Promote Puerto Rican Independence', 1, 99, 3),
(3220001, 1970, 3, 22, '40.70', '-73.93', 'Revolutionary movement against the financial establishment', 83, 3, 3),
(4080002, 1970, 4, 8, '37.02', '-94.74', 'Protest the strike', 999, 99, 7),
(4080003, 1970, 4, 8, '34.10', '-118.41', 'To protest the poor quality of education at a school district made up primarily of Mexican-Americans', 999, 99, 9),
(4090001, 1970, 4, 9, '38.62', '-90.15', 'Protest non-local companies from working in East St. Louis', 76, 6, 3),
(4110002, 1970, 4, 11, '42.46', '-76.48', 'To destabilize Cornell University', 102, 99, 2),
(4150002, 1970, 4, 15, '34.10', '-118.41', 'Intimidate pro-Castro sympathizers and protest Fidel Castros government', 1, 4, 7),
(4200001, 1970, 4, 20, '38.95', '-95.26', 'This attack occurred during heightened racial tensions in Lawrence Kansas.', 1, 20, 3),
(4210002, 1970, 4, 21, '34.10', '-118.41', 'Bank of America was perceived to symbolize the "capitalist exploitation of the little man."', 5, 99, 7),
(4230003, 1970, 4, 23, '18.38', '-67.19', 'To cripple the telecommunications facilities of Puerto Rico', 8, 16, 7),
(4240003, 1970, 4, 24, '40.70', '-73.93', 'Protest the Vietnam War and US military', 8, 9, 7),
(4270003, 1970, 4, 27, '42.06', '-87.68', 'Protest military research conducted at Northwestern University.', 1, 1, 7),
(4270006, 1970, 4, 27, '38.79', '-90.50', 'Protest "river-saving" legislation in St. Charles Missouri.', 1, 99, 7),
(5000001, 1970, 5, 0, '42.29', '-71.05', 'To scare White Catholic residents of the Dorchester out of the area', 1, 99, 3),
(5010008, 1970, 5, 1, '40.11', '-88.24', 'Protest the treatment of African Americans in Champaign Illinois', 1, 99, 3),
(5040002, 1970, 5, 4, '39.65', '-79.18', 'Protest barbershop owners who were not part of the union', 135, 1, 3),
(5040004, 1970, 5, 4, '35.22', '-97.45', 'Protest the draft', 1, 99, 3),
(5040005, 1970, 5, 4, '40.35', '-94.87', 'Protest the National Guard and the US military', 25, 4, 2),
(5050005, 1970, 5, 5, '28.54', '-81.38', 'Protest the United States government', 1, 99, 7),
(5060006, 1970, 5, 6, '45.51', '-122.68', 'Protest and sabotage the draft', 23, 3, 7),
(5090003, 1970, 5, 9, '38.55', '-121.47', 'To punish Sacramento Police officers for their treatment of African Americans', 68, 1, 3),
(5130001, 1970, 5, 13, '41.58', '-93.62', 'To kill police officers', 183, 3, 7),
(5140002, 1970, 5, 14, '40.70', '-73.93', 'Protest the administration of Columbia University and the Vietnam War', 2, 99, 3),
(5140004, 1970, 5, 14, '36.31', '-78.59', 'To protest and intimidate the White community of Oxford North Carolina', 3, 16, 2),
(5200003, 1970, 5, 20, '25.77', '-80.21', 'To protest the dilapidated conditions of the school, the busing of the students, and the fact that f', 288, 99, 3),
(5220002, 1970, 5, 22, '44.95', '-93.14', 'To kill police indiscriminately', 2, 5, 3),
(5270003, 1970, 5, 27, '42.30', '-71.07', 'To scare Jewish residents of the Dorchester out of the area', 100, 99, 3),
(6080002, 1970, 6, 8, '37.79', '-122.23', 'To attack the establishment', 1, 5, 7),
(6230003, 1970, 6, 23, '37.76', '-122.44', 'To protest the Vietnam War and the draft', 4, 90, 3),
(6300001, 1970, 6, 30, '40.62', '-74.42', 'To spark community wide turmoil', 2, 99, 7),
(7010004, 1970, 7, 1, '38.91', '-77.02', 'To protest the policies of the Organization of American States', 13, 40, 7),
(7140002, 1970, 7, 14, '40.70', '-73.93', 'Protest the draft and the US military', 1, 99, 3),
(7160003, 1970, 7, 16, '44.94', '-93.09', 'To protest and sabotage the draft', 89, 1, 7),
(7200001, 1970, 7, 20, '40.70', '-73.93', 'To protest the Jewish agencys operations in a predominantly Black community.', 68, 1, 3),
(9020002, 1970, 9, 2, '37.76', '-122.44', 'Offensive against police', 20, 15, 3),
(9090003, 1970, 9, 9, '43.07', '-89.39', 'To protest the Kaleidoscope newspaper position towards the bombing of the Army Math Research Center ', 1, 50, 7);

-- --------------------------------------------------------

--
-- Table structure for table `event_weapon_detail`
--

CREATE TABLE IF NOT EXISTS `event_weapon_detail` (
  `Event_ID` int(11) NOT NULL,
  `Weapon_type_ID` int(11) NOT NULL,
  PRIMARY KEY (`Event_ID`,`Weapon_type_ID`),
  KEY `Event_weapon_detail_Weapon_Type` (`Weapon_type_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_weapon_detail`
--

INSERT INTO `event_weapon_detail` (`Event_ID`, `Weapon_type_ID`) VALUES
(1190003, 1),
(1300003, 1),
(3010006, 1),
(2230005, 2),
(1220002, 3),
(2040001, 3),
(2060007, 3),
(2130003, 3),
(2170004, 3),
(2210005, 3),
(2240003, 3),
(2240002, 5),
(1190002, 6),
(1260001, 7),
(2060001, 7),
(2060002, 7),
(2080001, 7),
(2090004, 7),
(2220002, 7),
(3010005, 7),
(2170003, 9);

-- --------------------------------------------------------

--
-- Table structure for table `newtest_table`
--

CREATE TABLE IF NOT EXISTS `newtest_table` (
  `column1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newtest_table`
--


-- --------------------------------------------------------

--
-- Table structure for table `newtest_table01`
--

CREATE TABLE IF NOT EXISTS `newtest_table01` (
  `col1` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newtest_table01`
--


-- --------------------------------------------------------

--
-- Table structure for table `region`
--

CREATE TABLE IF NOT EXISTS `region` (
  `Region_ID` int(11) NOT NULL,
  `Region_Name` varchar(100) NOT NULL,
  `Country_ID` int(11) NOT NULL,
  PRIMARY KEY (`Region_ID`),
  KEY `idx_Cntry` (`Country_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `region`
--

INSERT INTO `region` (`Region_ID`, `Region_Name`, `Country_ID`) VALUES
(1, 'North America', 130),
(2, 'Central America & Caribbean', 58),
(3, 'South America', 218),
(4, 'East Asia', 101),
(5, 'Southeast Asia', 160),
(6, 'South Asia', 153),
(7, 'Central Asia', 74),
(8, 'Western Europe', 78),
(9, 'Eastern Europe', 499),
(10, 'Middle East & North Africa', 102),
(11, 'Sub-Saharan Africa', 65),
(12, 'Australasia & Oceania', 14);

-- --------------------------------------------------------

--
-- Table structure for table `target_subtype`
--

CREATE TABLE IF NOT EXISTS `target_subtype` (
  `Target_subtype_id` int(11) NOT NULL,
  `target_subtype` varchar(100) NOT NULL,
  `Target_type_id` int(11) NOT NULL,
  PRIMARY KEY (`Target_subtype_id`),
  KEY `Target_subtype_Target_type` (`Target_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `target_subtype`
--

INSERT INTO `target_subtype` (`Target_subtype_id`, `target_subtype`, `Target_type_id`) VALUES
(1, 'Gas/Oil/Electric', 1),
(2, 'Restaurant/Bar/Café', 1),
(3, 'Bank/Commerce', 1),
(4, 'Multinational Corporation', 1),
(5, 'Industrial/Textiles/Factory', 1),
(6, 'Medical/Pharmaceutical', 1),
(7, 'Retail/Grocery/Bakery', 1),
(8, 'Hotel/Resort', 1),
(9, 'Farm/Ranch', 1),
(10, 'Mining', 1),
(11, 'Entertainment/Cultural/Stadium/Casino', 1),
(12, 'Construction', 1),
(13, 'Private Security Company/Firm', 1),
(14, 'Judge/Attorney/Court', 2),
(15, 'Politician or Political Party Movement/Meeting/Rally', 2),
(16, 'Royalty', 2),
(17, 'Head of State', 2),
(18, 'Government Personnel (excluding police, military)', 2),
(19, 'Election-related', 2),
(20, 'Intelligence', 2),
(21, 'Government Building/Facility/Office', 2),
(22, 'Police Building (headquarters, station, school)', 3),
(23, 'Police Patrol (including vehicles and convoys)', 3),
(24, 'Police Checkpoint', 3),
(25, 'Police Security Forces/Officers', 3),
(26, 'Prison/Jail', 3),
(27, 'Military Barracks/Base/Headquarters/Checkpost', 4),
(28, 'Military Recruiting Station/Academy', 4),
(29, 'Military Unit/Patrol/Convoy', 4),
(30, 'Military Weaponry', 4),
(31, 'Military Aircraft', 4),
(32, 'Military Maritime', 4),
(33, 'Non-combatant Personnel', 4),
(34, 'Military Personnel (soldiers, troops, officers, forces)', 4),
(35, 'Military Transportation/Vehicle (excluding convoys)', 4),
(36, 'Military Checkpoint', 4),
(37, 'NATO', 4),
(39, 'Paramilitary', 4),
(40, 'Clinics', 5),
(41, 'Personnel', 5),
(42, 'Aircraft (not at an airport)', 6),
(43, 'Airline Officer/Personnel', 6),
(44, 'Airport', 6),
(45, 'Diplomatic Personnel (outside of embassy, consulate)', 7),
(46, 'Embassy/Consulate', 7),
(47, 'International Organization (peacekeeper, aid agency, compound)', 7),
(48, 'Teacher/Professor/Instructor', 8),
(49, 'School/University/Educational Building', 8),
(50, 'Other Personnel', 8),
(51, 'Food Supply', 9),
(52, 'Water Supply', 9),
(53, 'Newspaper Journalist/Staff/Facility', 10),
(54, 'Radio Journalist/Staff/Facility', 10),
(55, 'Television Journalist/Staff/Facility', 10),
(56, 'Other (including online news agencies)', 10),
(57, 'Civilian Maritime', 11),
(58, 'Commercial Maritime', 11),
(59, 'Oil Tanker', 11),
(60, 'Port', 11),
(61, 'Domestic NGO', 12),
(62, 'International NGO', 12),
(63, 'Ambulance', 13),
(64, 'Fire Fighter/Truck', 13),
(65, 'Refugee (including Camps/IDP/Asylum Seekers)', 14),
(66, 'Demilitarized Zone (including Green Zone)', 13),
(67, 'Unnamed Civilian/Unspecified', 14),
(68, 'Named Civilian', 14),
(69, 'Religion Identified', 14),
(70, 'Student', 14),
(71, 'Race/Ethnicity Identified', 14),
(72, 'Farmer', 14),
(73, 'Vehicles/Transportation', 14),
(74, 'Marketplace/Plaza/Square', 14),
(75, 'Village/City/Town/Suburb', 14),
(76, 'House/Apartment/Residence', 14),
(77, 'Laborer (General)/Occupation Identified', 14),
(78, 'Procession/Gathering (funeral, wedding, birthday, religious)', 14),
(79, 'Public Area (garden, parking lot, garage, beach, public building, camp)', 14),
(80, 'Memorial/Cemetery/Monument', 14),
(81, 'Museum/Cultural Center/Cultural House', 14),
(82, 'Labor Union Related', 14),
(83, 'Protester', 14),
(84, 'Political Party Member/Rally', 14),
(85, 'Religious Figure', 15),
(86, 'Place of Worship', 15),
(87, 'Affiliated Institution', 15),
(88, 'Radio', 16),
(89, 'Television', 16),
(90, 'Telephone/Telegraph', 16),
(91, 'Internet Infrastructure', 16),
(92, 'Multiple Telecommunication Targets', 16),
(93, 'Terrorist', 17),
(94, 'Non-State Militia', 17),
(95, ');Tourism Travel Agency', 18),
(96, 'Tour Bus/Van', 18),
(97, 'Tourist', 18),
(98, 'Other Facility', 18),
(99, 'Bus (excluding tourists)', 19),
(100, 'Train/Train Tracks/Trolley', 19),
(101, 'Bus Station/Stop', 19),
(102, 'Subway', 19),
(103, 'Bridge/Car Tunnel', 19),
(104, 'Highway/Road/Toll/Traffic Signal', 19),
(105, 'Taxi/Rickshaw', 19),
(106, 'Gas', 21),
(107, 'Electricity', 21),
(108, 'Oil', 21),
(109, 'Party Official/Candidate/Other Personnel', 22),
(110, 'Party Office/Facility', 22),
(111, 'Rally', 22),
(112, 'Legal Services', 1),
(113, 'Alleged Informant', 14);

-- --------------------------------------------------------

--
-- Table structure for table `target_type`
--

CREATE TABLE IF NOT EXISTS `target_type` (
  `Target_type_id` int(11) NOT NULL,
  `target_type` varchar(100) NOT NULL,
  PRIMARY KEY (`Target_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `target_type`
--

INSERT INTO `target_type` (`Target_type_id`, `target_type`) VALUES
(1, 'Business'),
(2, 'Government (General)'),
(3, 'Police'),
(4, 'Military'),
(5, 'Abortion Related'),
(6, 'Airports & Aircraft'),
(7, 'Government (Diplomatic)'),
(8, 'Educational Institution'),
(9, 'Food or Water Supply'),
(10, 'Journalists & Media'),
(11, 'Maritime'),
(12, 'NGO'),
(13, 'Other'),
(14, 'Private Citizens & Property'),
(15, 'Religious Figures/Institutions'),
(16, 'Telecommunication'),
(17, 'Terrorists/Non-State Militia'),
(18, 'Tourists'),
(19, 'Transportation'),
(20, 'Unknown'),
(21, 'Utilities'),
(22, 'Violent Political Party');

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_eventdetail`
--
CREATE TABLE IF NOT EXISTS `view_eventdetail` (
`Year` int(11)
,`MONTH` int(11)
,`Total_incidents` bigint(21)
,`Total_victims` decimal(32,0)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `weaponsubtype`
--
CREATE TABLE IF NOT EXISTS `weaponsubtype` (
`WEAPON_TYPE_ID` int(11)
,`COUNT(WEAPON_SUBTYPE_ID)` bigint(21)
);
-- --------------------------------------------------------

--
-- Table structure for table `weapon_subtype`
--

CREATE TABLE IF NOT EXISTS `weapon_subtype` (
  `Weapon_subtype_id` int(11) NOT NULL,
  `weapon_subtype` varchar(100) NOT NULL,
  `Weapon_type_ID` int(11) NOT NULL,
  PRIMARY KEY (`Weapon_subtype_id`),
  KEY `idx_01` (`Weapon_type_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `weapon_subtype`
--

INSERT INTO `weapon_subtype` (`Weapon_subtype_id`, `weapon_subtype`, `Weapon_type_ID`) VALUES
(1, 'Poisoning', 2),
(2, 'Automatic or Semi-Automatic Rifle', 5),
(3, 'Handgun', 5),
(4, 'Rifle/Shotgun (non-automatic)', 5),
(5, 'Unknown Gun Type', 5),
(6, 'Other Gun Type', 5),
(7, 'Grenade', 6),
(8, 'Landmine', 6),
(9, 'Letter Bomb', 6),
(10, 'Pressure Trigger', 6),
(11, 'Projectile (rockets, mortars, RPGs, etc.)', 6),
(12, 'Remote Trigger', 6),
(13, 'Suicide (carried bodily by human being)', 6),
(14, 'Time Fuse', 6),
(15, 'Vehicle', 6),
(16, 'Unknown Explosive Type', 6),
(17, 'Other Explosive Type', 6),
(18, 'Arson/Fire', 8),
(19, 'Molotov Cocktail/Petrol Bomb', 8),
(20, 'Gasoline or Alcohol', 8),
(21, 'Blunt Object', 9),
(22, 'Hands, Feet, Fists', 9),
(23, 'Knife or Other Sharp Object', 9),
(24, 'Rope or Other Strangling Device', 9),
(26, 'Suffocation', 9),
(27, 'Unknown Weapon Type', 9),
(28, 'Dynamite/TNT', 6),
(29, 'Sticky Bomb', 6),
(30, 'Explosive', 2),
(31, 'Pipe Bomb', 6);

-- --------------------------------------------------------

--
-- Table structure for table `weapon_type`
--

CREATE TABLE IF NOT EXISTS `weapon_type` (
  `Weapon_type_ID` int(11) NOT NULL,
  `Weapon_type` varchar(100) NOT NULL,
  `Weapon_detail` varchar(200) NOT NULL,
  PRIMARY KEY (`Weapon_type_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `weapon_type`
--

INSERT INTO `weapon_type` (`Weapon_type_ID`, `Weapon_type`, `Weapon_detail`) VALUES
(1, 'Biological', 'Anthrax'),
(2, 'Highly Chemical', 'Cyanide in water supply'),
(3, 'Radiological', 'Iodine 131'),
(5, 'Firearms', 'Several gunshots were fired.'),
(6, 'Explosives', 'Explosive'),
(7, 'Fake Weapons', 'Fake bomb'),
(8, 'Incendiary', 'Incendiary'),
(9, 'Melee', 'Axe handles'),
(10, 'Vehicle (not to include vehicle-borne explosives, i.e., car or truck bombs)', 'Run down by car'),
(11, 'Sabotage Equipment', 'Nuts, bolts, and other metallic objects placed in the gears'),
(12, 'Other', 'Smoke bomb'),
(13, 'Unknown', '');

--
-- Triggers `weapon_type`
--
DROP TRIGGER IF EXISTS `before_WP_update`;
DELIMITER //
CREATE TRIGGER `before_WP_update` BEFORE UPDATE ON `weapon_type`
 FOR EACH ROW INSERT INTO before_weapon_update
 SET 
     weapon_type_ID = OLD.weapon_type_ID,
     Weapontype= OLD.weapon_type,
weapon_detail=OLD.weapon_detail
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure for view `view_eventdetail`
--
DROP TABLE IF EXISTS `view_eventdetail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`::1` SQL SECURITY DEFINER VIEW `view_eventdetail` AS select `event_detail`.`Year` AS `Year`,`event_detail`.`Month` AS `MONTH`,count(`event_detail`.`Event_ID`) AS `Total_incidents`,sum(`event_detail`.`number_of_victims`) AS `Total_victims` from `event_detail` group by 1,2;

-- --------------------------------------------------------

--
-- Structure for view `weaponsubtype`
--
DROP TABLE IF EXISTS `weaponsubtype`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`::1` SQL SECURITY DEFINER VIEW `weaponsubtype` AS (select `weapon_subtype`.`Weapon_type_ID` AS `WEAPON_TYPE_ID`,count(`weapon_subtype`.`Weapon_subtype_id`) AS `COUNT(WEAPON_SUBTYPE_ID)` from `weapon_subtype` group by 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `event_detail`
--
ALTER TABLE `event_detail`
  ADD CONSTRAINT `Event_detail_Attack_type` FOREIGN KEY (`Attack_tyepeid`) REFERENCES `attack_type` (`Attack_tyepeid`);

--
-- Constraints for table `event_weapon_detail`
--
ALTER TABLE `event_weapon_detail`
  ADD CONSTRAINT `Event_weapon_detail_Event_detail` FOREIGN KEY (`Event_ID`) REFERENCES `event_detail` (`Event_ID`),
  ADD CONSTRAINT `Event_weapon_detail_Weapon_Type` FOREIGN KEY (`Weapon_type_ID`) REFERENCES `weapon_type` (`Weapon_type_ID`);

--
-- Constraints for table `region`
--
ALTER TABLE `region`
  ADD CONSTRAINT `Region_Country` FOREIGN KEY (`Country_ID`) REFERENCES `country` (`Country_ID`);

--
-- Constraints for table `target_subtype`
--
ALTER TABLE `target_subtype`
  ADD CONSTRAINT `Target_subtype_Target_type` FOREIGN KEY (`Target_type_id`) REFERENCES `target_type` (`Target_type_id`);

--
-- Constraints for table `weapon_subtype`
--
ALTER TABLE `weapon_subtype`
  ADD CONSTRAINT `Weapon_Type_ID` FOREIGN KEY (`Weapon_type_ID`) REFERENCES `weapon_type` (`Weapon_type_ID`);
